import logging
import os
import threading
from PIL import Image
import pystray
from pystray import Menu, MenuItem

class SystemTray:
    def __init__(self, gui):
        self.gui = gui
        self.icon_path = os.path.join(os.path.dirname(__file__), "..", "icon.ico")
        self.setup_tray()

    def setup_tray(self):
        if not self.gui.show_in_tray.get():
            return
        try:
            if os.path.exists(self.icon_path):
                image = Image.open(self.icon_path)
            else:
                image = Image.new('RGB', (16, 16), color=(0, 128, 255))
                logging.warning(f"Icon file 'icon.ico' not found at {self.icon_path}. Using fallback image.")
            tray = pystray.Icon("Minecraft Command Modifier", image, "Minecraft Command Modifier", Menu(
                MenuItem("Open", self.gui.show_window),
                MenuItem("Settings", self.gui.show_settings),
                MenuItem("Exit", self.exit_app)
            ))
            def run_tray():
                tray.run()
            tray_thread = threading.Thread(target=run_tray, daemon=True)
            tray_thread.start()
            self.gui.set_tray(tray)
            logging.info("Tray icon initialized successfully")
        except Exception as e:
            logging.error(f"Failed to initialize tray icon: {str(e)}")
            self.gui.show_in_tray.set(False)

    def exit_app(self):
        self.gui.root.destroy()
        if self.gui.tray:
            self.gui.tray.stop()
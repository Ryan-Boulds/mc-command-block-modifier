import logging
import sys
from src.gui import CommandModifierGUI
from src.command_processor import CommandProcessor
from src.system_tray import SystemTray
from src.utils import setup_logging, cleanup

def main():
    setup_logging()
    logging.info("Application started (F12 clipboard mode with GUI)")

    gui = None
    try:
        command_processor = CommandProcessor()
        gui = CommandModifierGUI(command_processor)
        command_processor.set_gui(gui)  # Link GUI to processor
        SystemTray(gui)  # Instantiate without assigning to variable
        gui.run()
    except KeyboardInterrupt:
        logging.info("Application interrupted by user")
        if gui:
            gui.print_to_text("", "normal")
            gui.print_to_text("Input Command:", "normal")
            gui.print_to_text("Exiting program.", "normal")
            gui.print_to_text("", "normal")
    except Exception as e:
        logging.error(f"Application error: {e}")
        sys.exit(1)
    finally:
        if gui:
            gui.on_closing()  # Ensure proper cleanup of GUI and tray
        cleanup()
        logging.info("Application exiting")

if __name__ == "__main__":
    main()